/*******************************************************************************
* File Name: WAV_FORM_ISR.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_WAV_FORM_ISR_H)
#define CY_ISR_WAV_FORM_ISR_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void WAV_FORM_ISR_Start(void);
void WAV_FORM_ISR_StartEx(cyisraddress address);
void WAV_FORM_ISR_Stop(void);

CY_ISR_PROTO(WAV_FORM_ISR_Interrupt);

void WAV_FORM_ISR_SetVector(cyisraddress address);
cyisraddress WAV_FORM_ISR_GetVector(void);

void WAV_FORM_ISR_SetPriority(uint8 priority);
uint8 WAV_FORM_ISR_GetPriority(void);

void WAV_FORM_ISR_Enable(void);
uint8 WAV_FORM_ISR_GetState(void);
void WAV_FORM_ISR_Disable(void);

void WAV_FORM_ISR_SetPending(void);
void WAV_FORM_ISR_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the WAV_FORM_ISR ISR. */
#define WAV_FORM_ISR_INTC_VECTOR            ((reg32 *) WAV_FORM_ISR__INTC_VECT)

/* Address of the WAV_FORM_ISR ISR priority. */
#define WAV_FORM_ISR_INTC_PRIOR             ((reg32 *) WAV_FORM_ISR__INTC_PRIOR_REG)

/* Priority of the WAV_FORM_ISR interrupt. */
#define WAV_FORM_ISR_INTC_PRIOR_NUMBER      WAV_FORM_ISR__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable WAV_FORM_ISR interrupt. */
#define WAV_FORM_ISR_INTC_SET_EN            ((reg32 *) WAV_FORM_ISR__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the WAV_FORM_ISR interrupt. */
#define WAV_FORM_ISR_INTC_CLR_EN            ((reg32 *) WAV_FORM_ISR__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the WAV_FORM_ISR interrupt state to pending. */
#define WAV_FORM_ISR_INTC_SET_PD            ((reg32 *) WAV_FORM_ISR__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the WAV_FORM_ISR interrupt. */
#define WAV_FORM_ISR_INTC_CLR_PD            ((reg32 *) WAV_FORM_ISR__INTC_CLR_PD_REG)



#endif /* CY_ISR_WAV_FORM_ISR_H */


/* [] END OF FILE */
